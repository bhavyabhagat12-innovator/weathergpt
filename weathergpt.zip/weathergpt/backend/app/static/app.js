document.addEventListener("DOMContentLoaded", () => {
  const chatViewport = document.getElementById("chat-viewport");
  const chatForm = document.getElementById("chat-form");
  const queryInput = document.getElementById("query-input");
  const rolePills = document.getElementById("role-pills");
  const suggestionsBox = document.getElementById("suggestions");
  const langSelect = document.getElementById("lang-select");
  const alertBanner = document.getElementById("live-alert-banner");
  const bannerText = document.getElementById("banner-text");
  const bannerClose = document.getElementById("banner-close");
  const connStatus = document.getElementById("conn-status");

  let currentRole = "general";
  let currentLanguage = "en";
  const sessionId = "session-" + Math.random().toString(36).substring(2, 9);

  const MULTILINGUAL_SUGGESTIONS = {
    en: {
      general: ["Will it rain in Delhi today?", "Current weather in Mumbai", "Weekend forecast in Bengaluru"],
      agriculture: ["Can I harvest onions in Nashik today?", "Is soil moisture adequate in Nagpur?", "Spraying window in Pune tomorrow?"],
      aviation: ["Flight landing briefing for Delhi runway", "Convective CAPE levels near Mumbai", "Wind gusts in Bengaluru airspace"],
      marine: ["Are conditions safe for fishing in Visakhapatnam?", "Severe cyclone warning in Bay of Bengal", "Port wind advisory in Chennai"],
      disaster_management: ["Active Red and Orange IMD warning bulletins", "Flash flood alerts in Konkan ghats", "Cyclone track bulletin for coastal Andhra"]
    },
    hi: {
      general: ["क्या आज दिल्ली में बारिश होगी?", "मुंबई में वर्तमान तापमान क्या है?", "बेंगलुरु का मौसम कैसा रहेगा?"],
      agriculture: ["क्या आज नासिक में प्याज की कटाई कर सकते हैं?", "क्या नागपुर में बुवाई के लिए नमी पर्याप्त है?", "पुणे में कल कीटनाशक छिड़काव कर सकते हैं?"],
      aviation: ["दिल्ली हवाई अड्डे के लिए उड़ान मौसम रिपोर्ट", "मुंबई के पास तूफान और हवा की स्थिति", "बेंगलुरु रनवे पर दृश्यता"],
      marine: ["क्या विशाखापट्टनम में मछुआरों के लिए जाना सुरक्षित है?", "बंगाल की खाड़ी में चक्रवात की स्थिति", "चेन्नई बंदरगाह पर हवा की गति"],
      disaster_management: ["सक्रिय रेड और ऑरेंज अलर्ट बुलेटिन", "कोंकण में भारी बारिश की चेतावनी", "तटीय चक्रवात आपातकालीन निर्देश"]
    },
    mr: {
      general: ["आज पुण्यात पाऊस पडेल का?", "मुंबईचे आजचे हवामान काय आहे?", "नाशिकमध्ये उद्या ऊन पडेल का?"],
      agriculture: ["नाशिकमध्ये आज कांदा काढणी करावी का?", "नागपुरात पेरणीसाठी जमिनीतील ओलावा पुरेसा आहे का?", "पुण्यात उद्या फवारणी योग्य आहे का?"],
      aviation: ["मुंबई विमानतळावरील वाऱ्याचा वेग", "विमान लँडिंगसाठी दृश्यता किती आहे?"],
      marine: ["विशाखापट्टणम किनाऱ्यावर मच्छीमारांसाठी इशारा", "चक्रीवादळाचा धोका किती आहे?"],
      disaster_management: ["कोकणात अतिवृष्टीचा रेड अलर्ट आहे का?", "पूर परिस्थितीची ताजी माहिती"]
    },
    ta: {
      general: ["சென்னையில் இன்று மழை பெய்யுமா?", "மதுரையின் தற்போதைய வெப்பநிலை"],
      agriculture: ["இன்று பயிர் அறுவடை செய்யலாமா?", "நாளை உரம் தெளிக்க தகுந்த வானிலையா?"],
      aviation: ["சென்னை விமான நிலைய வானிலை அறிக்கை"],
      marine: ["விசாகப்பட்டினத்தில் மீனவர்கள் கடலுக்கு செல்லலாமா?", "வங்கக்கடலில் புயல் எச்சரிக்கை"],
      disaster_management: ["தீவிர மழை எச்சரிக்கை மற்றும் புயல் தகவல்"]
    },
    te: {
      general: ["హైదరాబాద్‌లో ఈరోజు వర్షం పడుతుందా?", "విజయవాడలో ప్రస్తుత ఉష్ణోగ్రత"],
      agriculture: ["ఈరోజు పంట కోత చేయవచ్చా?", "రైతులకు విత్తనాల సలహా"],
      aviation: ["విమాన రాకపోకల వాతావరణ సమాచారం"],
      marine: ["విశాఖపట్నం సముద్రంలో చేపల వేటకు వెళ్ళవచ్చా?", "బంగాళాఖాతంలో తీవ్ర తుఫాను హెచ్చరిక"],
      disaster_management: ["తీరప్రాంత తుఫాను అత్యవసర హెచ్చరికలు"]
    }
  };

  // Connect WebSocket for proactive real-time severe alerts
  function setupWebSocket() {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws/alerts`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      connStatus.textContent = "Live Alerts Active";
      connStatus.style.color = "#10b981";
    };

    socket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === "weather_alert") {
          const alert = msg.alert;
          bannerText.textContent = `${alert.headline}: ${alert.instruction}`;
          alertBanner.className = `emergency-banner ${alert.severity === "red" ? "" : "orange"}`;
          alertBanner.classList.remove("hidden");
        }
      } catch (err) {
        console.error("Error parsing alert event:", err);
      }
    };

    socket.onclose = () => {
      connStatus.textContent = "Reconnecting...";
      connStatus.style.color = "#eab308";
      setTimeout(setupWebSocket, 3000);
    };
  }

  setupWebSocket();

  bannerClose.addEventListener("click", () => {
    alertBanner.classList.add("hidden");
  });

  function updateSuggestions() {
    suggestionsBox.innerHTML = "";
    const langDict = MULTILINGUAL_SUGGESTIONS[currentLanguage] || MULTILINGUAL_SUGGESTIONS.en;
    const list = langDict[currentRole] || langDict.general || [];
    list.forEach(text => {
      const chip = document.createElement("button");
      chip.className = "suggestion-chip";
      chip.textContent = text;
      chip.type = "button";
      chip.addEventListener("click", () => {
        queryInput.value = text;
        chatForm.dispatchEvent(new Event("submit"));
      });
      suggestionsBox.appendChild(chip);
    });
  }

  langSelect.addEventListener("change", (e) => {
    currentLanguage = e.target.value;
    updateSuggestions();
  });

  // Handle role switching
  rolePills.addEventListener("click", (e) => {
    const btn = e.target.closest(".role-pill");
    if (!btn) return;
    document.querySelectorAll(".role-pill").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    currentRole = btn.dataset.role;
    updateSuggestions();
  });

  updateSuggestions();


  function appendUserMessage(text) {
    const bubble = document.createElement("div");
    bubble.className = "message-bubble user";
    bubble.textContent = text;
    chatViewport.appendChild(bubble);
    chatViewport.scrollTop = chatViewport.scrollHeight;
  }

  function appendTypingIndicator() {
    const bubble = document.createElement("div");
    bubble.className = "message-bubble assistant typing-bubble";
    bubble.id = "typing-bubble";
    bubble.innerHTML = `
      <div class="sender-tag">Grounding Telemetry & Reasoning...</div>
      <div class="typing-indicator">
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
      </div>
    `;
    chatViewport.appendChild(bubble);
    chatViewport.scrollTop = chatViewport.scrollHeight;
    return bubble;
  }

  function appendAssistantResponse(data) {
    const typingBubble = document.getElementById("typing-bubble");
    if (typingBubble) typingBubble.remove();

    const bubble = document.createElement("div");
    bubble.className = "message-bubble assistant";

    // Format markdown-like bold and bullet text safely
    let formatted = data.answer
      .replace(/### (.*?)\n/g, "<h3 style='margin: 8px 0 4px 0; color: #7dd3fc; font-size: 1rem;'>$1</h3>")
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\n\n/g, "<p style='margin-bottom: 8px;'></p>")
      .replace(/\n- /g, "<br>• ");

    let alertsHtml = "";
    if (data.active_alerts && data.active_alerts.length > 0) {
      alertsHtml = data.active_alerts.map(a => {
        const cls = a.includes("RED") ? "red" : (a.includes("ORANGE") ? "orange" : "yellow");
        return `<div class="alert-badge ${cls}">${a}</div>`;
      }).join("");
    }

    // Telemetry metric chips
    const facts = data.grounded_facts || {};
    const chips = [];
    if (facts.current_temperature_c !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Temp:</span> <span class="metric-value">${facts.current_temperature_c}°C</span></div>`);
    }
    if (facts.relative_humidity_pct !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Humidity:</span> <span class="metric-value">${facts.relative_humidity_pct}%</span></div>`);
    }
    if (facts.forecast_today_rain_probability_pct !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Rain Prob:</span> <span class="metric-value">${facts.forecast_today_rain_probability_pct}%</span></div>`);
    }
    if (facts.wind_speed_kmh !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Wind:</span> <span class="metric-value">${facts.wind_speed_kmh} km/h</span></div>`);
    }
    if (facts.soil_moisture_0_7cm !== undefined && facts.soil_moisture_0_7cm !== null) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Soil (0-7cm):</span> <span class="metric-value">${Number(facts.soil_moisture_0_7cm).toFixed(3)} m³/m³</span></div>`);
    }
    if (facts.nwp_cape_j_kg !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">CAPE:</span> <span class="metric-value">${facts.nwp_cape_j_kg} J/kg</span></div>`);
    }

    const citationsText = (data.citations || []).slice(0, 3).join(" • ");

    bubble.innerHTML = `
      <div class="sender-tag">${data.role.toUpperCase()} ADVISORY • ${facts.query_location || "INDIA"}</div>
      ${alertsHtml}
      <div class="advisory-content">${formatted}</div>
      <div class="grounding-card">
        <div class="grounding-header">
          <span>Telemetry Audit (${data.report_id})</span>
          <span>⚡ ${data.latency_ms}ms</span>
        </div>
        <div class="telemetry-grid">
          ${chips.join("")}
        </div>
        <div class="citations-row">
          <span>Sources: ${citationsText}</span>
          <span style="color: #10b981;">✓ Zero Hallucination Grounded</span>
        </div>
      </div>
    `;

    chatViewport.appendChild(bubble);
    chatViewport.scrollTop = chatViewport.scrollHeight;
  }

  // ── Voice Recognition (Step 7) ──────────────────────────────────────
  const VOICE_LOCALE_MAP = {
    en: "en-IN", hi: "hi-IN", mr: "mr-IN", ta: "ta-IN", te: "te-IN"
  };

  const micBtn = document.getElementById("mic-btn");
  let recognition = null;
  let isListening = false;

  if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript.trim();
      queryInput.value = transcript;
      chatForm.dispatchEvent(new Event("submit"));
    };

    recognition.onerror = (event) => {
      console.error("Speech recognition error:", event.error);
      stopListening();
    };

    recognition.onend = () => stopListening();

    micBtn.addEventListener("click", () => {
      if (isListening) {
        recognition.stop();
      } else {
        startListening();
      }
    });
  } else {
    micBtn.title = "Voice input not supported in this browser";
    micBtn.style.opacity = "0.4";
    micBtn.style.cursor = "not-allowed";
  }

  function startListening() {
    if (!recognition) return;
    recognition.lang = VOICE_LOCALE_MAP[currentLanguage] || "en-IN";
    recognition.start();
    isListening = true;
    micBtn.classList.add("listening");
    micBtn.title = "Listening… click to stop";
  }

  function stopListening() {
    isListening = false;
    micBtn.classList.remove("listening");
    micBtn.title = "Click to speak your query";
  }

  // ── TTS helper ──────────────────────────────────────────────────────
  function speakText(text, lang) {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text.replace(/[#*`]/g, ""));
    utt.lang = VOICE_LOCALE_MAP[lang || currentLanguage] || "en-IN";
    utt.rate = 0.95;
    window.speechSynthesis.speak(utt);
  }

  // ── Inline Chart Renderer (Step 8) ──────────────────────────────────
  function renderChart(chartSpec) {
    if (!chartSpec || !chartSpec.labels || !chartSpec.values) return "";
    const labels = chartSpec.labels;
    const values = chartSpec.values;
    const baseline = chartSpec.baseline_normal || null;
    const unit = chartSpec.unit || "mm";
    const title = chartSpec.title || "Climate Trend";
    const trend = chartSpec.trend_summary || "";

    const maxVal = Math.max(...values, baseline || 0, 1);

    const rows = labels.map((label, i) => {
      const val = values[i];
      const pct = Math.round((val / maxVal) * 100);
      let barClass = "chart-bar";
      if (baseline !== null) {
        barClass += val > baseline * 1.1 ? " above-normal" : (val < baseline * 0.9 ? " below-normal" : "");
      }
      return `
        <div class="chart-bar-row">
          <span class="chart-label">${label}</span>
          <div class="chart-bar-wrap">
            <div class="${barClass}" style="width:${pct}%"></div>
          </div>
          <span class="chart-value">${val} ${unit}</span>
        </div>`;
    }).join("");

    const baselineRow = baseline !== null
      ? `<div class="chart-baseline"></div><div class="chart-bar-row"><span class="chart-label" style="color:#64748b">Normal</span><div class="chart-bar-wrap"><div class="chart-bar" style="width:${Math.round((baseline/maxVal)*100)}%;background:#334155;"></div></div><span class="chart-value" style="color:#64748b">${baseline} ${unit}</span></div>`
      : "";

    return `
      <div class="chart-container">
        <div class="chart-title">${title}</div>
        ${rows}
        ${baselineRow}
        ${trend ? `<div class="chart-trend">${trend}</div>` : ""}
      </div>`;
  }

  function appendUserMessage(text) {
    const bubble = document.createElement("div");
    bubble.className = "message-bubble user";
    bubble.textContent = text;
    chatViewport.appendChild(bubble);
    chatViewport.scrollTop = chatViewport.scrollHeight;
  }

  function appendTypingIndicator() {
    const bubble = document.createElement("div");
    bubble.className = "message-bubble assistant typing-bubble";
    bubble.id = "typing-bubble";
    bubble.innerHTML = `
      <div class="sender-tag">Grounding Telemetry &amp; Reasoning...</div>
      <div class="typing-indicator">
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
      </div>
    `;
    chatViewport.appendChild(bubble);
    chatViewport.scrollTop = chatViewport.scrollHeight;
    return bubble;
  }

  function appendAssistantResponse(data) {
    const typingBubble = document.getElementById("typing-bubble");
    if (typingBubble) typingBubble.remove();

    const bubble = document.createElement("div");
    bubble.className = "message-bubble assistant";

    // Format markdown-like bold and bullet text safely
    let formatted = data.answer
      .replace(/### (.*?)\n/g, "<h3 style='margin: 8px 0 4px 0; color: #7dd3fc; font-size: 1rem;'>$1</h3>")
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\n\n/g, "<p style='margin-bottom: 8px;'></p>")
      .replace(/\n- /g, "<br>• ");

    let alertsHtml = "";
    if (data.active_alerts && data.active_alerts.length > 0) {
      alertsHtml = data.active_alerts.map(a => {
        const cls = a.includes("RED") ? "red" : (a.includes("ORANGE") ? "orange" : "yellow");
        return `<div class="alert-badge ${cls}">${a}</div>`;
      }).join("");
    }

    // Telemetry metric chips
    const facts = data.grounded_facts || {};
    const chips = [];
    if (facts.current_temperature_c !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Temp:</span> <span class="metric-value">${facts.current_temperature_c}°C</span></div>`);
    }
    if (facts.relative_humidity_pct !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Humidity:</span> <span class="metric-value">${facts.relative_humidity_pct}%</span></div>`);
    }
    if (facts.forecast_today_rain_probability_pct !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Rain Prob:</span> <span class="metric-value">${facts.forecast_today_rain_probability_pct}%</span></div>`);
    }
    if (facts.wind_speed_kmh !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Wind:</span> <span class="metric-value">${facts.wind_speed_kmh} km/h</span></div>`);
    }
    if (facts.soil_moisture_0_7cm !== undefined && facts.soil_moisture_0_7cm !== null) {
      chips.push(`<div class="metric-chip"><span class="metric-label">Soil (0-7cm):</span> <span class="metric-value">${Number(facts.soil_moisture_0_7cm).toFixed(3)} m³/m³</span></div>`);
    }
    if (facts.nwp_cape_j_kg !== undefined) {
      chips.push(`<div class="metric-chip"><span class="metric-label">CAPE:</span> <span class="metric-value">${facts.nwp_cape_j_kg} J/kg</span></div>`);
    }

    const citationsText = (data.citations || []).slice(0, 3).join(" • ");

    // Climate chart HTML (Step 8)
    const chartHtml = data.chart_spec ? renderChart(data.chart_spec) : "";

    bubble.innerHTML = `
      <div class="sender-tag">${data.role.toUpperCase()} ADVISORY • ${facts.query_location || "INDIA"}</div>
      ${alertsHtml}
      <div class="advisory-content">${formatted}</div>
      ${chartHtml}
      <div class="grounding-card">
        <div class="grounding-header">
          <span>Telemetry Audit (${data.report_id})</span>
          <span>⚡ ${data.latency_ms}ms</span>
        </div>
        <div class="telemetry-grid">
          ${chips.join("")}
        </div>
        <div class="citations-row">
          <span>Sources: ${citationsText}</span>
          <button class="tts-btn" title="Read aloud">🔊</button>
          <span style="color: #10b981;">✓ Zero Hallucination Grounded</span>
        </div>
      </div>
    `;

    // Wire TTS button
    const ttsBtn = bubble.querySelector(".tts-btn");
    if (ttsBtn) {
      ttsBtn.addEventListener("click", () => speakText(data.answer, data.language || currentLanguage));
    }

    chatViewport.appendChild(bubble);
    chatViewport.scrollTop = chatViewport.scrollHeight;
  }

  // Handle message submission
  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const query = queryInput.value.trim();
    if (!query) return;

    appendUserMessage(query);
    queryInput.value = "";
    appendTypingIndicator();

    try {
      const response = await fetch("/api/v1/chat/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: query,
          session_id: sessionId,
          role: currentRole,
          language: currentLanguage
        })
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.statusText}`);
      }

      const data = await response.json();
      appendAssistantResponse(data);
    } catch (err) {
      const typingBubble = document.getElementById("typing-bubble");
      if (typingBubble) typingBubble.remove();

      const bubble = document.createElement("div");
      bubble.className = "message-bubble assistant";
      bubble.innerHTML = `<span style="color: #ef4444;">Error connecting to WeatherGPT: ${err.message}</span>`;
      chatViewport.appendChild(bubble);
      chatViewport.scrollTop = chatViewport.scrollHeight;
    }
  });
});


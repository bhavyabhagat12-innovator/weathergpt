"""
App API package init.
"""

from app.api.main import app

__all__ = ["app"]

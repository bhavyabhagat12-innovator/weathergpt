"""
API routes package init.
"""

from app.api.routes.data import router as data_router

__all__ = ["data_router"]

"""
WeatherGPT application package.
"""

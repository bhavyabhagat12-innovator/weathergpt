"""
WeatherGPT test suite package.
"""
